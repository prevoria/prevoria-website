# Prevoria — Next.js + Tailwind landing

## Run locally
npm install
npm run dev

Open http://localhost:3000
